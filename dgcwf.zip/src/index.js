import React from "react";
import ReactDOM from "react-dom";
import { createStore } from "redux";
import "./styles.css";
import reduced from "./con";
import { Provider } from "react-redux";
import { useSelector, useDispatch } from "react-redux";
import { increment, decrement } from "./actions";
const store = createStore(
  reduced,
  window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
);
function App() {
  const counter = useSelector(state => state.reducer);
  const dispatch = useDispatch();
  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
      <h2>Start editing to see some magic happen!</h2>
      <h1>Counter = {counter}</h1>
      <button onClick={() => dispatch(increment(2))}>+</button>
      <button onClick={() => dispatch(decrement(3))}>+</button>
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  rootElement
);
