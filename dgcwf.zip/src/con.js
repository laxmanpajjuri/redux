import reducer from "./reducer1";
import red from "./reducer2";
import { combineReducers } from "redux";
const reduced = combineReducers({
  reducer,
  red
});
export default reduced;
